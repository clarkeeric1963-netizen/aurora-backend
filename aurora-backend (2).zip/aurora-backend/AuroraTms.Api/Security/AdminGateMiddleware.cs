using System.Security.Cryptography;
using System.Text;

namespace AuroraTms.Api.Security;

/// <summary>
/// A simple stopgap gate over the super-admin surface: the /admin onboarding UI
/// and the platform endpoints it uses (/api/customers and /api/users). Requires
/// a valid "admin_auth" cookie, which is issued by /admin/login after the correct
/// ADMIN_PASSWORD is entered. Fails closed: if ADMIN_PASSWORD isn't configured,
/// nothing admin-related is reachable.
///
/// This is NOT the full auth system — it's a lock on the door while we build the
/// real provider-based login. Tenant data routes are untouched here.
/// </summary>
public class AdminGateMiddleware
{
    private readonly RequestDelegate _next;
    public AdminGateMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext ctx)
    {
        var path = ctx.Request.Path.Value ?? "";

        bool isAdminArea = path.StartsWith("/admin", StringComparison.OrdinalIgnoreCase);
        bool isLoginRoute = path.StartsWith("/admin/login", StringComparison.OrdinalIgnoreCase)
                         || path.StartsWith("/admin/logout", StringComparison.OrdinalIgnoreCase);
        bool isPlatformApi = path.StartsWith("/api/customers", StringComparison.OrdinalIgnoreCase)
                          || path.StartsWith("/api/users", StringComparison.OrdinalIgnoreCase);

        bool needsGate = (isAdminArea && !isLoginRoute) || isPlatformApi;
        if (!needsGate || IsAuthed(ctx))
        {
            await _next(ctx);
            return;
        }

        if (isPlatformApi)
        {
            ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
            await ctx.Response.WriteAsJsonAsync(new { error = "Admin login required." });
            return;
        }

        // Admin page request with no session -> send to the login page.
        ctx.Response.Redirect("/admin/login.html");
    }

    /// <summary>The cookie value that proves admin access (HMAC of a fixed string keyed by the password).</summary>
    public static string? ExpectedToken()
    {
        var pw = Environment.GetEnvironmentVariable("ADMIN_PASSWORD");
        if (string.IsNullOrEmpty(pw)) return null;
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(pw));
        return Convert.ToHexString(hmac.ComputeHash(Encoding.UTF8.GetBytes("aurora-admin-session-v1")));
    }

    private static bool IsAuthed(HttpContext ctx)
    {
        var expected = ExpectedToken();
        if (expected is null) return false; // not configured -> fail closed
        var cookie = ctx.Request.Cookies["admin_auth"];
        if (string.IsNullOrEmpty(cookie)) return false;
        return CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(cookie), Encoding.UTF8.GetBytes(expected));
    }
}
