using System.Security.Cryptography;
using System.Text;
using AuroraTms.Api.Security;
using Microsoft.AspNetCore.Mvc;

namespace AuroraTms.Api.Controllers;

[ApiController]
public class AdminAuthController : ControllerBase
{
    public record LoginRequest(string? Password);

    [HttpPost("/admin/login")]
    public IActionResult Login([FromBody] LoginRequest req)
    {
        var pw = Environment.GetEnvironmentVariable("ADMIN_PASSWORD");
        if (string.IsNullOrEmpty(pw))
            return StatusCode(503, new { error = "Admin login isn't configured yet. Set the ADMIN_PASSWORD variable." });

        var supplied = req?.Password ?? "";
        bool ok = CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(supplied), Encoding.UTF8.GetBytes(pw));
        if (!ok)
            return Unauthorized(new { error = "Incorrect password." });

        Response.Cookies.Append("admin_auth", AdminGateMiddleware.ExpectedToken()!, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Lax,
            Path = "/",
            MaxAge = TimeSpan.FromHours(8)
        });
        return Ok(new { ok = true });
    }

    [HttpPost("/admin/logout")]
    public IActionResult Logout()
    {
        Response.Cookies.Delete("admin_auth", new CookieOptions { Path = "/" });
        return Ok(new { ok = true });
    }
}
